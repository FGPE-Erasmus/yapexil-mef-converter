def derivative(b, m):
    d = b * m
    d = d ** (b - 1)
    return d
