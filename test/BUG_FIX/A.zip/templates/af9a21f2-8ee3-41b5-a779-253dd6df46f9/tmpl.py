b = int(input().strip())
m = int(input().strip())

{{code}}

print(derivative(b, m))
