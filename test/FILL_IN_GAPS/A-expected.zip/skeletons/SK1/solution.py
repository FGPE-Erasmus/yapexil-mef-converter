b = int(input().strip())
m = int(input().strip())

def derivative(b, m):
    return b * m ** {{gap}}


print(derivative(b, m))
