public static boolean isPrime(int n) {
  // your code here
}
