b = int(input().strip())
m = int(input().strip())

def derivative(b, m):
    {{code}}
    return d

print(derivative(b, m))
