d = b
d = d * m
d = d ** (b - 1)