def derivative(b, m):
