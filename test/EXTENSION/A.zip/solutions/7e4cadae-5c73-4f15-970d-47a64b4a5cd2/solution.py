def derivative(b, m):
    return b * m ** (b - 1)