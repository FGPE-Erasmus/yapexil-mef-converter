b = int(input().strip())
m = int(input().strip())

def derivative(b, m):


print(derivative(b, m))
