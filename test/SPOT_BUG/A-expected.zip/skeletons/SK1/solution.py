b = int(input().strip())
m = int(input().strip())

def derivative(b, m):
    return b * m ** b


print(derivative(b, m))
